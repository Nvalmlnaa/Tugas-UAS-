package com.example.kyriad_muraya_hotel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
